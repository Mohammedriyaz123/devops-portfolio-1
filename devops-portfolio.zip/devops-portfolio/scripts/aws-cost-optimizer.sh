#!/bin/bash
################################################################################
# AWS Cost Optimization Script — Mohamed Al Riyaz DevOps Portfolio
# Identifies and reports unused/oversized resources to reduce AWS spend
# Usage: ./aws-cost-optimizer.sh [--region ap-south-1] [--dry-run]
################################################################################

set -euo pipefail

REGION="${AWS_REGION:-ap-south-1}"
DRY_RUN=false
LOG_FILE="/var/log/aws-cost-optimizer-$(date +%Y%m%d).log"

# ── Parse args ────────────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
    case $1 in
        --region)   REGION="$2"; shift 2 ;;
        --dry-run)  DRY_RUN=true; shift ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"; }

log "======================================================"
log "AWS Cost Optimization Report — Region: $REGION"
log "Dry run: $DRY_RUN"
log "======================================================"

# ── 1. Unattached EBS Volumes ─────────────────────────────────────────────────
log "Checking for unattached EBS volumes..."
UNATTACHED_VOLUMES=$(aws ec2 describe-volumes \
    --region "$REGION" \
    --filters Name=status,Values=available \
    --query 'Volumes[*].[VolumeId,Size,VolumeType,CreateTime]' \
    --output table)

if [[ -n "$UNATTACHED_VOLUMES" ]]; then
    log "⚠️  Unattached EBS Volumes found:"
    echo "$UNATTACHED_VOLUMES" | tee -a "$LOG_FILE"
else
    log "✅ No unattached EBS volumes"
fi

# ── 2. Unused Elastic IPs ─────────────────────────────────────────────────────
log "Checking for unused Elastic IPs..."
UNUSED_EIPS=$(aws ec2 describe-addresses \
    --region "$REGION" \
    --query 'Addresses[?AssociationId==null].[PublicIp,AllocationId]' \
    --output table)

if [[ -n "$UNUSED_EIPS" ]]; then
    log "⚠️  Unused Elastic IPs found (charged even when idle):"
    echo "$UNUSED_EIPS" | tee -a "$LOG_FILE"
else
    log "✅ No unused Elastic IPs"
fi

# ── 3. Stopped EC2 Instances (still incurring EBS costs) ─────────────────────
log "Checking for stopped EC2 instances..."
STOPPED_INSTANCES=$(aws ec2 describe-instances \
    --region "$REGION" \
    --filters Name=instance-state-name,Values=stopped \
    --query 'Reservations[*].Instances[*].[InstanceId,InstanceType,Tags[?Key==`Name`].Value|[0],LaunchTime]' \
    --output table)

if [[ -n "$STOPPED_INSTANCES" ]]; then
    log "⚠️  Stopped EC2 instances:"
    echo "$STOPPED_INSTANCES" | tee -a "$LOG_FILE"
else
    log "✅ No stopped EC2 instances"
fi

# ── 4. Old Snapshots (>30 days) ───────────────────────────────────────────────
log "Checking for old EBS snapshots (>30 days)..."
CUTOFF_DATE=$(date -d '30 days ago' +%Y-%m-%dT%H:%M:%S)
OLD_SNAPSHOTS=$(aws ec2 describe-snapshots \
    --region "$REGION" \
    --owner-ids self \
    --query "Snapshots[?StartTime<='${CUTOFF_DATE}'].[SnapshotId,VolumeSize,StartTime,Description]" \
    --output table)

if [[ -n "$OLD_SNAPSHOTS" ]]; then
    log "⚠️  Old snapshots (>30 days) — consider cleanup:"
    echo "$OLD_SNAPSHOTS" | tee -a "$LOG_FILE"
fi

# ── 5. Underutilised EC2 (CPU < 5% over 7 days) ──────────────────────────────
log "Checking for underutilised EC2 instances (CPU < 5%)..."
END_TIME=$(date -u +%Y-%m-%dT%H:%M:%S)
START_TIME=$(date -u -d '7 days ago' +%Y-%m-%dT%H:%M:%S)

aws ec2 describe-instances \
    --region "$REGION" \
    --filters Name=instance-state-name,Values=running \
    --query 'Reservations[*].Instances[*].[InstanceId,InstanceType]' \
    --output text | while read INSTANCE_ID INSTANCE_TYPE; do

    AVG_CPU=$(aws cloudwatch get-metric-statistics \
        --region "$REGION" \
        --namespace AWS/EC2 \
        --metric-name CPUUtilization \
        --dimensions Name=InstanceId,Value="$INSTANCE_ID" \
        --start-time "$START_TIME" \
        --end-time "$END_TIME" \
        --period 604800 \
        --statistics Average \
        --query 'Datapoints[0].Average' \
        --output text 2>/dev/null || echo "0")

    if (( $(echo "$AVG_CPU < 5" | bc -l) )); then
        log "⚠️  Underutilised: $INSTANCE_ID ($INSTANCE_TYPE) — Avg CPU: ${AVG_CPU}% — consider downsizing"
    fi
done

log "======================================================"
log "Report complete. Log saved to: $LOG_FILE"
log "======================================================"
