# 🚀 DevOps Portfolio — Mohamed Al Riyaz

> Associate Cloud & DevOps Engineer | AWS & Azure Certified | 3+ Years Experience

[![AWS](https://img.shields.io/badge/AWS-Certified-orange?logo=amazon-aws)](https://aws.amazon.com)
[![Azure](https://img.shields.io/badge/Azure-AZ204-blue?logo=microsoft-azure)](https://azure.microsoft.com)
[![Terraform](https://img.shields.io/badge/IaC-Terraform-purple?logo=terraform)](https://terraform.io)
[![Kubernetes](https://img.shields.io/badge/Orchestration-Kubernetes-blue?logo=kubernetes)](https://kubernetes.io)
[![Docker](https://img.shields.io/badge/Container-Docker-blue?logo=docker)](https://docker.com)
[![Jenkins](https://img.shields.io/badge/CI/CD-Jenkins-red?logo=jenkins)](https://jenkins.io)

---

## 📁 Repository Structure

```
devops-portfolio/
├── terraform/              # Infrastructure as Code — AWS multi-env setup
│   ├── modules/
│   │   ├── vpc/            # Reusable VPC module
│   │   ├── ec2/            # EC2 Auto Scaling module
│   │   └── rds/            # RDS (MySQL) module
│   └── environments/
│       ├── dev/
│       ├── staging/
│       └── prod/
├── kubernetes/             # K8s manifests for EKS deployments
│   ├── deployments/
│   ├── services/
│   ├── configmaps/
│   └── helm/               # Helm chart for the app
├── ci-cd/
│   ├── jenkins/            # Jenkinsfile with multi-stage pipeline
│   └── github-actions/     # GitHub Actions workflows
├── ansible/                # Configuration management playbooks
│   ├── playbooks/
│   └── roles/
├── docker/                 # Multi-stage Dockerfiles
└── scripts/                # Utility bash/python scripts
```

---

## 🏗️ Architecture Overview

```
                          ┌─────────────────────────────────────────┐
                          │              AWS Cloud (VPC)             │
                          │                                          │
  Developer ──► GitHub ──►│  Jenkins/GitHub Actions (CI/CD)         │
                          │         │                                │
                          │         ▼                                │
                          │   ECR (Docker Registry)                  │
                          │         │                                │
                          │         ▼                                │
                          │  ┌─────────────┐    ┌───────────────┐   │
                          │  │   EKS       │    │   RDS (MySQL) │   │
                          │  │  (Pods)     │───►│               │   │
                          │  └─────────────┘    └───────────────┘   │
                          │         │                                │
                          │         ▼                                │
                          │  ALB (Load Balancer)                     │
                          │         │                                │
                          └─────────┼───────────────────────────────┘
                                    ▼
                               End Users
```

---

## 🛠️ Projects in This Portfolio

### 1. 🌐 Terraform — Multi-Environment AWS Infrastructure
**[`/terraform`](./terraform/)**

- Reusable modules for VPC, EC2 (with Auto Scaling), and RDS
- Separate state management per environment (dev/staging/prod)
- Remote state stored in S3 with DynamoDB locking
- **Impact:** Reduced environment setup time by 80%

### 2. ☸️ Kubernetes — EKS Deployment Manifests
**[`/kubernetes`](./kubernetes/)**

- Production-grade Deployment with rolling update strategy
- HorizontalPodAutoscaler (HPA) for automatic scaling
- ConfigMaps and Secrets management
- Helm chart for reusable app packaging
- **Impact:** Zero-downtime deployments across 3 environments

### 3. 🔄 CI/CD Pipelines
**[`/ci-cd`](./ci-cd/)**

- **Jenkins:** Multi-stage pipeline (Build → Test → Scan → Push → Deploy)
- **GitHub Actions:** Automated workflow with Docker build & EKS deploy
- **Impact:** Reduced deployment cycle time by 40%

### 4. ⚙️ Ansible — Configuration Management
**[`/ansible`](./ansible/)**

- Automated EC2 provisioning and configuration
- Roles for common setup, webserver, and Docker installation
- **Impact:** Eliminated manual server configuration effort by 60%

### 5. 🐳 Docker — Multi-Stage Builds
**[`/docker`](./docker/)**

- Optimised multi-stage Dockerfile (build image vs runtime image)
- Nginx reverse proxy configuration
- **Impact:** Reduced image size by ~70% using multi-stage builds

---

## 📊 Key Metrics Achieved

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Deployment Cycle Time | ~5 hrs | ~3 hrs | **40% faster** |
| Server Provisioning Time | ~4 hrs | ~30 mins | **80% reduction** |
| Monthly AWS Spend | Rs. 8L | Rs. 6.8L | **15% cost saving** |
| Manual Ops Effort | High | Low | **50% reduction** |

---

## 🏅 Certifications

| Certification | Issuer | Status |
|---|---|---|
| Azure Developer Associate (AZ-204) | Microsoft | ✅ Active |
| Azure Fundamentals (AZ-900) | Microsoft | ✅ Active |
| AWS Cloud Practitioner (CLF-C02) | Amazon | ✅ Active |

---

## 📬 Contact

- 📧 shahulriyaz1999@gmail.com
- 💼 [LinkedIn](https://www.linkedin.com/in/mohamed-al-riyaz)
- 🐙 [GitHub](https://github.com/Mohammedriyaz123)
- 📍 Bangalore, Karnataka, India
