#!/bin/bash
# ============================================================
# Run this script ONCE on your machine to push the portfolio
# Usage: bash push-to-github.sh
# ============================================================

GITHUB_USERNAME="Mohammedriyaz123"
REPO_NAME="devops-portfolio"

echo "🚀 Pushing DevOps Portfolio to GitHub..."

cd devops-portfolio

git init
git add .
git commit -m "feat: initial DevOps portfolio — Terraform, K8s, CI/CD, Ansible, Docker"
git branch -M main
git remote add origin https://github.com/${GITHUB_USERNAME}/${REPO_NAME}.git
git push -u origin main

echo "✅ Done! Visit: https://github.com/${GITHUB_USERNAME}/${REPO_NAME}"
