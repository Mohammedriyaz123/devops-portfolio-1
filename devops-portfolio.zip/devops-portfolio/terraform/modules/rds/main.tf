################################################################################
# RDS MySQL Module — Mohamed Al Riyaz DevOps Portfolio
################################################################################

variable "environment"    {}
variable "project_name"   {}
variable "vpc_id"         {}
variable "subnet_ids"     { type = list(string) }
variable "db_name"        { default = "appdb" }
variable "db_username"    { default = "admin" }
variable "db_password"    { sensitive = true }
variable "instance_class" { default = "db.t3.medium" }
variable "engine_version" { default = "8.0" }
variable "allocated_storage" { default = 20 }

resource "aws_db_subnet_group" "main" {
  name       = "${var.project_name}-${var.environment}-db-subnet"
  subnet_ids = var.subnet_ids
  tags       = { Name = "${var.project_name}-${var.environment}-db-subnet-group" }
}

resource "aws_security_group" "rds_sg" {
  name   = "${var.project_name}-${var.environment}-rds-sg"
  vpc_id = var.vpc_id

  ingress {
    from_port   = 3306
    to_port     = 3306
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/8"]
    description = "MySQL from VPC"
  }
  egress {
    from_port   = 0; to_port = 0; protocol = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_db_instance" "main" {
  identifier             = "${var.project_name}-${var.environment}-db"
  engine                 = "mysql"
  engine_version         = var.engine_version
  instance_class         = var.instance_class
  allocated_storage      = var.allocated_storage
  storage_encrypted      = true
  db_name                = var.db_name
  username               = var.db_username
  password               = var.db_password
  db_subnet_group_name   = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.rds_sg.id]
  multi_az               = var.environment == "prod" ? true : false
  skip_final_snapshot    = var.environment != "prod"
  deletion_protection    = var.environment == "prod" ? true : false
  backup_retention_period = var.environment == "prod" ? 7 : 1

  tags = { Environment = var.environment, ManagedBy = "Terraform" }
}

output "db_endpoint" { value = aws_db_instance.main.endpoint }
output "db_name"     { value = aws_db_instance.main.db_name }
