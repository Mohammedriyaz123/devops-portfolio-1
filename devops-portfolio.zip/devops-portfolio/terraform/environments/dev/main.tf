################################################################################
# Dev Environment — Mohamed Al Riyaz DevOps Portfolio
################################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.0" }
  }
  backend "s3" {
    bucket         = "riyaz-tfstate-dev"
    key            = "dev/terraform.tfstate"
    region         = "ap-south-1"
    dynamodb_table = "terraform-state-lock"
    encrypt        = true
  }
}

provider "aws" {
  region = "ap-south-1"
  default_tags { tags = { Project = "riyaz-devops", Environment = "dev", ManagedBy = "Terraform" } }
}

variable "ami_id"     {}
variable "key_name"   {}
variable "db_password" { sensitive = true }

module "vpc" {
  source       = "../../modules/vpc"
  environment  = "dev"
  project_name = "riyaz-devops"
  vpc_cidr     = "10.0.0.0/16"
}

module "ec2" {
  source           = "../../modules/ec2"
  environment      = "dev"
  project_name     = "riyaz-devops"
  vpc_id           = module.vpc.vpc_id
  subnet_ids       = module.vpc.private_subnet_ids
  instance_type    = "t3.small"
  ami_id           = var.ami_id
  key_name         = var.key_name
  min_size         = 1
  max_size         = 2
  desired_capacity = 1
}

module "rds" {
  source       = "../../modules/rds"
  environment  = "dev"
  project_name = "riyaz-devops"
  vpc_id       = module.vpc.vpc_id
  subnet_ids   = module.vpc.private_subnet_ids
  db_password  = var.db_password
}
