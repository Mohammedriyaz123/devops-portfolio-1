################################################################################
# Production Environment — Mohamed Al Riyaz DevOps Portfolio
################################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.0" }
  }
  # Remote state in S3 with DynamoDB locking
  backend "s3" {
    bucket         = "riyaz-tfstate-prod"
    key            = "prod/terraform.tfstate"
    region         = "ap-south-1"
    dynamodb_table = "terraform-state-lock"
    encrypt        = true
  }
}

provider "aws" {
  region = var.aws_region
  default_tags { tags = { Project = var.project_name, Environment = "prod", ManagedBy = "Terraform" } }
}

variable "aws_region"   { default = "ap-south-1" }
variable "project_name" { default = "riyaz-devops" }
variable "ami_id"       {}
variable "key_name"     {}
variable "db_password"  { sensitive = true }

module "vpc" {
  source       = "../../modules/vpc"
  environment  = "prod"
  project_name = var.project_name
  vpc_cidr     = "10.2.0.0/16"
}

module "ec2" {
  source           = "../../modules/ec2"
  environment      = "prod"
  project_name     = var.project_name
  vpc_id           = module.vpc.vpc_id
  subnet_ids       = module.vpc.private_subnet_ids
  instance_type    = "t3.large"
  ami_id           = var.ami_id
  key_name         = var.key_name
  min_size         = 2
  max_size         = 10
  desired_capacity = 3
}

module "rds" {
  source         = "../../modules/rds"
  environment    = "prod"
  project_name   = var.project_name
  vpc_id         = module.vpc.vpc_id
  subnet_ids     = module.vpc.private_subnet_ids
  instance_class = "db.t3.large"
  db_password    = var.db_password
}

output "vpc_id"       { value = module.vpc.vpc_id }
output "asg_name"     { value = module.ec2.asg_name }
output "db_endpoint"  { value = module.rds.db_endpoint }
